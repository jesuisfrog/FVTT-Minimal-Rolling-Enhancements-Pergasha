export const MODULE_NAME = "mre-pergasha";
export const MODULE_TITLE = "Minimal Rolling Enhancements for D&D5e";
export const MODULE_TITLE_SHORT = "MRE";
